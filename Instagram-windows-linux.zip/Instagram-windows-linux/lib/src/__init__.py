# Date: 05/11/2018
# Author: Pure-L0G1C
# Description: init file