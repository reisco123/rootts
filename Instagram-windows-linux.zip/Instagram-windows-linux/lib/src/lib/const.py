FETCH_TIME = 10
MAX_REQUESTS = 100
PROXY_URL = 'https://gimmeproxy.com/api/getProxy?get=true&post=true&supportsHttps=true&minSpeed={}&protocol={}&anonymityLevel=1&user-agent=true&referer=true&cookies=true'
HEADER_DETAILS = { 'referer': 'https://gimmeproxy.com', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36' }

